<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">


    <link rel="manifest" href="{{ asset('game/manifest.webmanifest') }}">
<meta name="theme-color" content="#000000">
<link rel="apple-touch-icon" href="{{ asset('game/icon-192.png') }}">
    <!-- TITLE -->
    <title>{{ $title ?? 'Ariatyx Gaming' }}</title>

    <!-- ✅ DYNAMIC FAVICON (IMPORTANT) -->
    <link rel="icon" type="image/png" href="{{ $favicon ?? asset('images/logo.png') }}">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@700&display=swap" rel="stylesheet">

    <!-- Scripts -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="font-sans antialiased">
    <div class="min-h-screen bg-black">

        <!-- NAVIGATION (HIDDEN ON GAME PAGE) -->
        @if (!Route::is('game.play')) 
            @include('layouts.navigation')
        @endif

        <!-- HEADER -->
        @isset($header)
            <header class="bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    {{ $header }}
                </div>
            </header>
        @endisset

        <!-- CONTENT -->
        <main>
            {{ $slot }}
        </main>

    </div>
</body>
</html>